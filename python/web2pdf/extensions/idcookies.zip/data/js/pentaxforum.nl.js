if (/cookies\.php/.test(document.location.href))
	document.getElementsByTagName('input')[1].click();