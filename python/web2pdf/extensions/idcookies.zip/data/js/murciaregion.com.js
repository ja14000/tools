if (document.querySelector('a[href*="IncluirIPCookies"]'))
	document.location.href = '/tusfotos/IncluirIPCookies.php';